
# iris data set analysis


```python
# import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
#reading a csv file
iris=pd.read_csv("C:\\Users\\Saikiran\\Desktop\\project data sets\\iris.csv")
```


```python
#head is used to know the top rows 
iris.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
#tail is used to know the least 5 rows
iris.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>145</th>
      <td>6.7</td>
      <td>3.0</td>
      <td>5.2</td>
      <td>2.3</td>
      <td>Iris-virginica</td>
    </tr>
    <tr>
      <th>146</th>
      <td>6.3</td>
      <td>2.5</td>
      <td>5.0</td>
      <td>1.9</td>
      <td>Iris-virginica</td>
    </tr>
    <tr>
      <th>147</th>
      <td>6.5</td>
      <td>3.0</td>
      <td>5.2</td>
      <td>2.0</td>
      <td>Iris-virginica</td>
    </tr>
    <tr>
      <th>148</th>
      <td>6.2</td>
      <td>3.4</td>
      <td>5.4</td>
      <td>2.3</td>
      <td>Iris-virginica</td>
    </tr>
    <tr>
      <th>149</th>
      <td>5.9</td>
      <td>3.0</td>
      <td>5.1</td>
      <td>1.8</td>
      <td>Iris-virginica</td>
    </tr>
  </tbody>
</table>
</div>




```python
#this is used to know the shape of the data set
iris.shape
```




    (150, 5)




```python
# is used to know the dataset, balanced or not
iris["species"].value_counts()
```




    Iris-virginica     50
    Iris-setosa        50
    Iris-versicolor    50
    Name: species, dtype: int64




```python
print(iris.describe())
```

           sepal_length  sepal_width  petal_length  petal_width
    count    150.000000   150.000000    150.000000   150.000000
    mean       5.843333     3.054000      3.758667     1.198667
    std        0.828066     0.433594      1.764420     0.763161
    min        4.300000     2.000000      1.000000     0.100000
    25%        5.100000     2.800000      1.600000     0.300000
    50%        5.800000     3.000000      4.350000     1.300000
    75%        6.400000     3.300000      5.100000     1.800000
    max        7.900000     4.400000      6.900000     2.500000
    


```python
iris.isnull().sum()
```




    sepal_length    0
    sepal_width     0
    petal_length    0
    petal_width     0
    species         0
    dtype: int64




```python
iris.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5.1</td>
      <td>3.5</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>4.9</td>
      <td>3.0</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.7</td>
      <td>3.2</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.6</td>
      <td>3.1</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>3.6</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.preprocessing import StandardScaler
iris[['sepal_length','sepal_width']] = StandardScaler().fit_transform(iris[['sepal_length','sepal_width']])
#iris[['Pclass','Sex','Age','SibSp','Parch', 'Fare','Embarked']] = StandardScaler().fit_transform(train[['Pclass','Sex','Age','SibSp','Parch', 'Fare','Embarked']])                          
```


```python
iris.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.900681</td>
      <td>1.032057</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-1.143017</td>
      <td>-0.124958</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-1.385353</td>
      <td>0.337848</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-1.506521</td>
      <td>0.106445</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-1.021849</td>
      <td>1.263460</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>Iris-setosa</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Import label encoder 
from sklearn import preprocessing 
  
# label_encoder object knows how to understand word labels. 
label_encoder = preprocessing.LabelEncoder() 
  
# Encode labels in column 'species'. 
iris['species']= label_encoder.fit_transform(iris['species']) 
```


```python
iris.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
      <th>species</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.900681</td>
      <td>1.032057</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-1.143017</td>
      <td>-0.124958</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-1.385353</td>
      <td>0.337848</td>
      <td>1.3</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-1.506521</td>
      <td>0.106445</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-1.021849</td>
      <td>1.263460</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-0.537178</td>
      <td>1.957669</td>
      <td>1.7</td>
      <td>0.4</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>-1.506521</td>
      <td>0.800654</td>
      <td>1.4</td>
      <td>0.3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>-1.021849</td>
      <td>0.800654</td>
      <td>1.5</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>-1.748856</td>
      <td>-0.356361</td>
      <td>1.4</td>
      <td>0.2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>-1.143017</td>
      <td>0.106445</td>
      <td>1.5</td>
      <td>0.1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
species=iris['species']
```


```python
iris=iris.drop('species',1)
```


```python
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(iris,species, test_size=0.2)
print (X_train.shape, y_train.shape)
print (X_test.shape, y_test.shape)
```

    (120, 4) (120,)
    (30, 4) (30,)
    


```python
from sklearn.neighbors import KNeighborsClassifier 
knn = KNeighborsClassifier(n_neighbors=5) 
knn.fit(X_train, y_train)
```




    KNeighborsClassifier(algorithm='auto', leaf_size=30, metric='minkowski',
                         metric_params=None, n_jobs=None, n_neighbors=5, p=2,
                         weights='uniform')




```python

```


```python

```


```python

```


```python
y_pred = knn.predict(X_test)
y_pred
```




    array(['Iris-virginica', 'Iris-versicolor', 'Iris-versicolor',
           'Iris-setosa', 'Iris-setosa', 'Iris-versicolor', 'Iris-setosa',
           'Iris-versicolor', 'Iris-virginica', 'Iris-setosa',
           'Iris-versicolor', 'Iris-virginica', 'Iris-setosa', 'Iris-setosa',
           'Iris-virginica', 'Iris-setosa', 'Iris-versicolor',
           'Iris-virginica', 'Iris-versicolor', 'Iris-setosa', 'Iris-setosa',
           'Iris-setosa', 'Iris-versicolor', 'Iris-setosa', 'Iris-versicolor',
           'Iris-virginica', 'Iris-virginica', 'Iris-virginica',
           'Iris-setosa', 'Iris-versicolor'], dtype=object)




```python
from sklearn import metrics 
print("kNN model accuracy:", metrics.accuracy_score(y_test, y_pred))
```

    kNN model accuracy: 0.9333333333333333
    


```python
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
print('Validation Results')
print('Accuracy Score: ', accuracy_score(y_test, y_pred))
print('Classification Report:')
print(classification_report(y_test, y_pred))
print('Confusion Matrix:')
confusion_matrix(y_test, y_pred)
```

    Validation Results
    Accuracy Score:  0.9333333333333333
    Classification Report:
                     precision    recall  f1-score   support
    
        Iris-setosa       1.00      1.00      1.00        12
    Iris-versicolor       0.80      1.00      0.89         8
     Iris-virginica       1.00      0.80      0.89        10
    
           accuracy                           0.93        30
          macro avg       0.93      0.93      0.93        30
       weighted avg       0.95      0.93      0.93        30
    
    Confusion Matrix:
    




    array([[12,  0,  0],
           [ 0,  8,  0],
           [ 0,  2,  8]], dtype=int64)




```python
!pip install -q scikit-plot
import scikitplot as skplt

skplt.metrics.plot_confusion_matrix(y_test, y_pred,figsize=(9,9))
plt.show()
```


![png](output_24_0.png)



```python
import warnings
warnings.filterwarnings('ignore')
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.ensemble import VotingClassifier

kfold = model_selection.KFold(n_splits=10, random_state=1)
# create the sub models
estimators = []
model1 = LogisticRegression()
estimators.append(('logistic', model1))
model2 = DecisionTreeClassifier()
estimators.append(('cart', model2))
model3 = SVC()
estimators.append(('svm', model3))
# create the ensemble model
ensemble = VotingClassifier(estimators)
results = model_selection.cross_val_score(ensemble,X_train, y_train, cv=kfold)
print(results.mean())
```

    0.975
    


```python

```

# conclusion
Finally after using ensembles models, i got accuracy 97%

```python

```

# 2d scatter plot


```python
#2d scatter plot for sepal length and sepal width
#here we can observe that setosa flowers are more separable then remaining two
sns.scatterplot(x="sepal_length", y="sepal_width", hue="species",data=iris)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x13f04a40f28>




![png](output_31_1.png)



```python
#In this 2d analysis is used sepal_length and petal_length, this is better that before one
sns.scatterplot(x="sepal_length", y="petal_length", hue="species",data=iris)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x13f04b38940>




![png](output_32_1.png)



```python
sns.scatterplot(x="sepal_length", y="petal_width", hue="species",data=iris)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x13f04bb9908>




![png](output_33_1.png)



```python
sns.pairplot(iris, hue = 'species')
```




    <seaborn.axisgrid.PairGrid at 0x13f0544aef0>




![png](output_34_1.png)



```python
#by using pair plot we can say that petal_lenght and petal_width are better than others,
#so using petal_lenght and petal_width is better for future analysis
```


```python
sns.scatterplot(x="petal_length", y="petal_width", hue="species",data=iris)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x13f05ec7d30>




![png](output_36_1.png)


# Determining the mean and median of the different species present in the data set


```python
iris.groupby('species').agg(['mean', 'median'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="2" halign="left">sepal_length</th>
      <th colspan="2" halign="left">sepal_width</th>
      <th colspan="2" halign="left">petal_length</th>
      <th colspan="2" halign="left">petal_width</th>
    </tr>
    <tr>
      <th></th>
      <th>mean</th>
      <th>median</th>
      <th>mean</th>
      <th>median</th>
      <th>mean</th>
      <th>median</th>
      <th>mean</th>
      <th>median</th>
    </tr>
    <tr>
      <th>species</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>setosa</th>
      <td>5.006</td>
      <td>5.0</td>
      <td>3.428</td>
      <td>3.4</td>
      <td>1.462</td>
      <td>1.50</td>
      <td>0.246</td>
      <td>0.2</td>
    </tr>
    <tr>
      <th>versicolor</th>
      <td>5.936</td>
      <td>5.9</td>
      <td>2.770</td>
      <td>2.8</td>
      <td>4.260</td>
      <td>4.35</td>
      <td>1.326</td>
      <td>1.3</td>
    </tr>
    <tr>
      <th>virginica</th>
      <td>6.588</td>
      <td>6.5</td>
      <td>2.974</td>
      <td>3.0</td>
      <td>5.552</td>
      <td>5.55</td>
      <td>2.026</td>
      <td>2.0</td>
    </tr>
  </tbody>
</table>
</div>



# Computing the Standard deviation —



```python
iris.groupby('species').std()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sepal_length</th>
      <th>sepal_width</th>
      <th>petal_length</th>
      <th>petal_width</th>
    </tr>
    <tr>
      <th>species</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>setosa</th>
      <td>0.352490</td>
      <td>0.379064</td>
      <td>0.173664</td>
      <td>0.105386</td>
    </tr>
    <tr>
      <th>versicolor</th>
      <td>0.516171</td>
      <td>0.313798</td>
      <td>0.469911</td>
      <td>0.197753</td>
    </tr>
    <tr>
      <th>virginica</th>
      <td>0.635880</td>
      <td>0.322497</td>
      <td>0.551895</td>
      <td>0.274650</td>
    </tr>
  </tbody>
</table>
</div>



# BOX plot


```python
sns.set(style="ticks") 
plt.figure(figsize=(12,10))
plt.subplot(2,2,1)
sns.boxplot(x='species',y='sepal_length',data=iris)
plt.subplot(2,2,2)
sns.boxplot(x='species',y='sepal_width',data=iris)
plt.subplot(2,2,3)
sns.boxplot(x='species',y='petal_length',data=iris)
plt.subplot(2,2,4)
sns.boxplot(x='species',y='petal_width',data=iris)
plt.show()
```


![png](output_42_0.png)


# violon plot


```python
sns.set(style="whitegrid")
plt.figure(figsize=(12,10))
plt.subplot(2,2,1)
sns.violinplot(x="species",y="sepal_length",data=iris)
plt.subplot(2,2,2)
sns.violinplot(x="species",y="sepal_width",data=iris)
plt.subplot(2,2,3)
sns.violinplot(x="species",y="petal_length",data=iris)
plt.subplot(2,2,4)
sns.violinplot(x="species",y="petal_width",data=iris)
plt.show()
```


![png](output_44_0.png)



```python
#iris_setosa = iris[iris["species"] == "setosa"]
#iris_versicolor = iris[iris["species"] == "versicolor"]
#iris_virginica = iris[iris["species"] == "virginica"]
```

# Plotting the Histogram & PDF using Seaborn FacetGrid object —


```python
sns.FacetGrid(iris, hue="species", height=5) \
   .map(sns.distplot, "sepal_length") \
   .add_legend();
sns.FacetGrid(iris, hue="species", height=5) \
   .map(sns.distplot, "sepal_width") \
   .add_legend();
sns.FacetGrid(iris, hue="species", height=5) \
   .map(sns.distplot, "petal_length") \
   .add_legend();
sns.FacetGrid(iris, hue="species", height=5) \
   .map(sns.distplot, "petal_width") \
   .add_legend();
```


![png](output_47_0.png)



![png](output_47_1.png)



![png](output_47_2.png)



![png](output_47_3.png)


# Plotting CDF and PDF for IRIS Setosa, Versicolor and Virginica flowers for comparative analysis of the petal length —


```python
plt.figure(figsize=(15,10))
counts, bin_edges = np.histogram(iris_setosa['petal_length'],
                                 bins = 10, density = True)
pdf = counts/sum(counts)
cdf = np.cumsum(pdf)
plt.plot(bin_edges[1:], pdf, label = 'Setosa PDF')
plt.plot(bin_edges[1:], cdf, label = 'Setosa CDF')
counts, bin_edges = np.histogram(iris_versicolor['petal_length'],
                                 bins = 10, density = True)
pdf = counts/sum(counts)
cdf = np.cumsum(pdf)
plt.plot(bin_edges[1:], pdf, label = 'Versicolor PDF')
plt.plot(bin_edges[1:], cdf, label = 'Versicolor CDF')
counts, bin_edges = np.histogram(iris_virginica['petal_length'],
                                 bins = 10, density = True)
pdf = counts/sum(counts)
cdf = np.cumsum(pdf)
plt.plot(bin_edges[1:], pdf, label = 'Virginica PDF')
plt.plot(bin_edges[1:], cdf, label = 'Virginica CDF')
plt.legend()
plt.show()

```


![png](output_49_0.png)


# my code 


```python
if petal_length <1.9:
    species='setosa'
elif petal_length > 3.2 and petal_length < 5:
    species = 'Versicolor'# (95% of accuracy)
elif petal_length > 5:
    species = 'Virginica' # (90% of accuracy)
```


```python

```
